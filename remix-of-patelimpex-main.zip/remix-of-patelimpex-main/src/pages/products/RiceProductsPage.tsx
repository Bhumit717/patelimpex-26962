import EnhancedProductCategoryTemplate from "@/components/EnhancedProductCategoryTemplate";

const RiceProductsPage = () => {
  const products = [
    { name: "1121 Golden Sella Basmati Rice", image: "https://widegarden.co/wp-content/uploads/2024/04/Untitled-design28.png", link: "/products/rice/golden-sella-1121", description: "Premium parboiled basmati with golden hue" },
    { name: "1121 White Sella Basmati Rice", image: "https://s.alicdn.com/@sc04/kf/S17d885839316423bb4d1070abc3e9c4cK/Top-Class-1121-Indian-Basmati-Rice-Rich-Aroma-and-Creamy-White-Sella-OEM-Customizable-Dried-Long-Pattern.jpg_300x300.jpg", link: "/products/rice/white-sella-1121", description: "Creamy white parboiled basmati" },
    { name: "1121 Steam Basmati Rice", image: "https://vamikainternational.com/upload/product/1121-steam-basmati-1686937153.png", link: "/products/rice/steam-1121", description: "Steam processed premium basmati" },
    { name: "IR64 Parboiled Rice", image: "https://5.imimg.com/data5/SELLER/Default/2025/2/485583940/MB/RJ/ZZ/189429300/ir-64-parboiled-rice-10-broken-500x500.jpg", link: "/products/rice/ir64-parboiled", description: "Non-basmati parboiled variety" },
    { name: "IR64 Raw Rice", image: "https://cpimg.tistatic.com/05946152/b/4/IR64-Parboiled-Rice.jpg", link: "/products/rice/ir64-raw", description: "Non-basmati white rice" },
    { name: "Sona Masoori Rice", image: "https://png.pngtree.com/png-clipart/20241119/original/pngtree-3d-sona-masoori-rice-sack-on-transparent-background-png-image_17233172.png", link: "/products/rice/sona-masoori", description: "Lightweight South Indian variety" },
    { name: "Jeerakasala Rice", image: "https://shop.tulsidas.com/cdn/shop/files/jeerakashala_rice_tulsidas_grande.jpg?v=1736229244", link: "/products/rice/jeerakasala", description: "Aromatic short-grain rice from Kerala" },
  ];

  return (
    <EnhancedProductCategoryTemplate
      category="Agricultural Products"
      title="Rice Products"
      description="Patel Impex exports premium-quality Rice products including Basmati and Non-Basmati varieties to global markets. Our range is carefully sourced from trusted farmers and processed under strict international quality standards."
      products={products}
      breadcrumbs={[{ label: "Products", href: "/products" }, { label: "Rice" }]}
      canonicalUrl="/products/rice"
      metaTitle="Rice Exporter India | Basmati & Non-Basmati | Patel Impex"
      metaDescription="Leading rice exporter from India. Premium basmati & non-basmati varieties. 1121, IR64, Sona Masoori. Bulk supply to 50+ countries."
    />
  );
};

export default RiceProductsPage;
