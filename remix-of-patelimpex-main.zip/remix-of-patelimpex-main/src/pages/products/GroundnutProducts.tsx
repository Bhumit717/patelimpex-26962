import ProductCategoryTemplate from "@/components/ProductCategoryTemplate";

const GroundnutProducts = () => {
  const products = [
    {
      name: "Bold/Runner/Virginia Groundnut",
      image: "https://www.agrocrops.com/front/blog/images/quality/superior-bold1.jpg",
      link: "/products/bold-runner-groundnut",
      description: "Larger, elongated kernels, often used in confectionery and peanut butter.",
    },
    {
      name: "Java/Spanish Groundnut",
      image: "https://skyagriexport.com/storage/app/productlist-images/1603447745java%20peanuts.png",
      link: "/products/java-spanish-groundnut",
      description: "Smaller, rounder kernels, preferred for snacks and oil extraction.",
    },
    {
      name: "TJ (Tikkam Jawar) Groundnut",
      image: "https://i0.wp.com/aumexports.com/wp-content/uploads/2020/10/TJ-Peanuts.jpg?fit=1536%2C809&ssl=1",
      link: "/products/tj-groundnut",
      description: "Specific varieties like TJ 37 and TJ Pathavada, known for their quality.",
    },
    {
      name: "G10 & G20 Premium Groundnut",
      image: "https://varniexports.com/assets/4-Dk7bxs3b.png",
      link: "/products/g10-g20-groundnut",
      description: "Premium varieties of Java peanuts with reddish, shiny appearance and strong shells.",
    },
  ];

  return (
    <ProductCategoryTemplate
      category="Oil Seeds"
      title="Groundnut Products"
      description="Patel Impex is a leading exporter of premium Indian groundnuts (peanuts) in various varieties and formats. Our groundnuts are sourced from the finest farms in Gujarat and processed under strict quality standards."
      products={products}
    />
  );
};

export default GroundnutProducts;
