import ProductCategoryTemplate from "@/components/ProductCategoryTemplate";
import psylliumHuskImg from "@/assets/products/psyllium-husk.png";
import psylliumHuskPowderImg from "@/assets/products/psyllium-husk-powder.png";
import psylliumSeedsImg from "@/assets/products/psyllium-seeds.png";

const PsylliumHuskProducts = () => {
  const products = [
    {
      name: "Psyllium Husk",
      image: psylliumHuskImg,
      link: "/products/psyllium-husk",
      description: "Outer covering of Plantago ovata seeds, widely used as natural laxative and dietary fiber supplement.",
      popularLinks: [
        { name: "Alibaba", url: "https://www.alibaba.com/showroom/psyllium-husk.html" },
        { name: "IndiaMART", url: "https://www.indiamart.com/proddetail/psyllium-husk.html" },
      ],
    },
    {
      name: "Psyllium Husk Powder",
      image: psylliumHuskPowderImg,
      link: "/products/psyllium-husk-powder",
      description: "Finely ground psyllium husk for easy mixing in beverages, food products, and supplements.",
      popularLinks: [
        { name: "Amazon", url: "https://www.amazon.com/s?k=psyllium+husk+powder" },
        { name: "TradeIndia", url: "https://www.tradeindia.com/search.html?keyword=psyllium+husk+powder" },
      ],
    },
    {
      name: "Psyllium Seeds",
      image: psylliumSeedsImg,
      link: "/products/psyllium-seeds",
      description: "Whole psyllium seeds (Isabgol seeds) used in traditional medicine and food industry.",
      popularLinks: [
        { name: "ExportHub", url: "https://www.exporthub.com/psyllium-seeds.html" },
        { name: "TradeKey", url: "https://www.tradekey.com/product_view/Psyllium-Seeds.htm" },
      ],
    },
  ];

  return (
    <ProductCategoryTemplate
      category="Herbs & Ayurvedic"
      title="Psyllium Husk Products"
      description="Patel Impex is a trusted exporter of premium-grade Psyllium (Plantago ovata) products sourced from India's leading agricultural zones. Psyllium is globally recognized for its natural dietary fiber content and digestive health benefits."
      products={products}
    />
  );
};

export default PsylliumHuskProducts;
