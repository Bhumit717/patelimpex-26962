import EnhancedProductCategoryTemplate from "@/components/EnhancedProductCategoryTemplate";

const CottonProductsPage = () => {
  const products = [
    { name: "Raw Cotton", image: "https://static.vecteezy.com/system/resources/previews/052/933/241/non_2x/raw-cotton-balls-isolated-on-a-transparent-background-free-png.png", link: "/products/cotton/raw-cotton", description: "Unprocessed cotton directly from farms" },
    { name: "Cotton Yarn", image: "https://static.vecteezy.com/system/resources/previews/056/565/930/non_2x/pink-cotton-yarn-ball-on-transparent-background-png.png", link: "/products/cotton/cotton-yarn", description: "Spun cotton yarn for textiles" },
    { name: "Comber Noil Cotton", image: "https://www.indiacottonindustries.com/wp-content/uploads/2021/11/comber-noil.jpg", link: "/products/cotton/comber-noil", description: "Short fiber cotton from combing process" },
    { name: "Cotton Carding Dropping", image: "https://s.alicdn.com/@sc04/kf/Uf5977419bcd841f6a19a0821ee0f4e68Z.jpg", link: "/products/cotton/carding-dropping", description: "Cotton waste from carding machines" },
    { name: "Processed Cotton", image: "https://t4.ftcdn.net/jpg/15/63/05/01/360_F_1563050122_9yQ3Y3swc9FnS0EsSomXeOgcki497vTn.jpg", link: "/products/cotton/processed", description: "Cleaned and processed cotton fiber" },
    { name: "Cotton Roving", image: "https://appleoakfibreworks.com/cdn/shop/products/cottonriving_1080x.jpg?v=1644925613", link: "/products/cotton/roving", description: "Intermediate product before spinning" },
  ];

  return (
    <EnhancedProductCategoryTemplate
      category="Textiles & Fibers"
      title="Cotton Products"
      description="Patel Impex exports a complete range of cotton products including raw cotton, cotton yarn, and various cotton waste products for textile and industrial applications."
      products={products}
      breadcrumbs={[{ label: "Products", href: "/products" }, { label: "Cotton" }]}
      canonicalUrl="/products/cotton"
      metaTitle="Cotton Exporter India | Raw Cotton & Yarn | Patel Impex"
      metaDescription="Leading cotton exporter from India. Raw cotton, yarn, comber noil, carding dropping. Premium quality for textile industries worldwide."
    />
  );
};

export default CottonProductsPage;
