import { Link } from "react-router-dom";
import { ArrowLeft, ArrowRight, ExternalLink } from "lucide-react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

interface PopularLink {
  name: string;
  url: string;
}

interface ProductVariety {
  name: string;
  image: string;
  link: string;
  description?: string;
  popularLinks?: PopularLink[];
}

interface ProductCategoryTemplateProps {
  category: string;
  title: string;
  description: string;
  bannerImage?: string;
  products: ProductVariety[];
  backLink?: string;
  backLinkText?: string;
}

const ProductCategoryTemplate = ({
  category,
  title,
  description,
  products,
  backLink = "/#products",
  backLinkText = "Back to Products",
}: ProductCategoryTemplateProps) => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="pt-24">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-teal-600 py-16 shadow-2xl">
          <div className="container mx-auto px-4">
            <Link 
              to={backLink} 
              className="inline-flex items-center text-white/80 hover:text-white mb-4 transition-colors"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              {backLinkText}
            </Link>
            <p className="text-blue-100 text-sm mb-2">{category}</p>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">{title}</h1>
            <p className="text-xl text-blue-100 max-w-3xl">{description}</p>
          </div>
        </div>

        {/* Products Grid */}
        <div className="container mx-auto px-4 py-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Our {title} Range</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product, index) => (
              <div
                key={index}
                className="group bg-white rounded-2xl overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.12)] hover:shadow-[0_20px_60px_rgb(0,0,0,0.2)] transition-all duration-500 hover:-translate-y-2 border border-transparent"
              >
                <Link to={product.link}>
                  <div className="relative h-48 overflow-hidden bg-gradient-to-br from-gray-50 to-gray-100 p-6 flex items-center justify-center">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="max-h-full max-w-full object-contain group-hover:scale-110 transition-transform duration-700"
                    />
                  </div>
                  <div className="p-6 pb-3">
                    <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {product.name}
                    </h3>
                    {product.description && (
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">{product.description}</p>
                    )}
                    <div className="flex items-center text-blue-600 font-semibold group-hover:text-blue-700">
                      <span>View Details</span>
                      <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-2 transition-transform duration-300" />
                    </div>
                  </div>
                </Link>
                
                {/* Popular Website Links */}
                {product.popularLinks && product.popularLinks.length > 0 && (
                  <div className="px-6 pb-5 pt-2 border-t border-gray-100">
                    <p className="text-xs text-gray-500 mb-2">Also available on:</p>
                    <div className="flex flex-wrap gap-2">
                      {product.popularLinks.map((link, linkIndex) => (
                        <a
                          key={linkIndex}
                          href={link.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-gradient-to-r from-blue-50 to-teal-50 text-blue-700 rounded-full hover:from-blue-100 hover:to-teal-100 transition-colors shadow-sm hover:shadow-md border border-transparent"
                        >
                          {link.name}
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default ProductCategoryTemplate;
