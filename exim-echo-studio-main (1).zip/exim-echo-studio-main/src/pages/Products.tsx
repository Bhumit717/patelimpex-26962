import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Wheat, ArrowRight, Globe, Star, Phone, Mail, Award, CheckCircle, Users, Target } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Helmet } from "react-helmet";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Import product images
import psylliumHuskImg from "@/assets/products/psyllium-husk.png";
import fennelSeedsImg from "@/assets/products/fennel-seeds.png";
import cuminSeedsImg from "@/assets/products/cumin-seeds.png";
import cottonImg from "@/assets/products/cotton.png";
import riceImg from "@/assets/products/rice.png";
import groundnutImg from "@/assets/products/groundnut.png";
import cardamomImg from "@/assets/products/cardamom.png";
import soybeanImg from "@/assets/products/soybean.png";
import wheatFlourImg from "@/assets/products/wheat-flour.png";

const Products = () => {
  const products = [
    { 
      name: "Psyllium Husk (Isabgol)", 
      image: psylliumHuskImg, 
      link: "/seo/psyllium-husk-export",
      description: "Premium quality psyllium husk for pharmaceutical and food industries",
      botanicalName: "Plantago Scabra",
      familyName: "Plantaginaceae",
      varieties: "Machine Clean & Sortex",
      availability: "Whole / Grounded (Powder)",
      specifications: [
        { parameter: "Purity", value: "99.5% / 99% / 98%" },
        { parameter: "Color", value: "Light brown to moderate brown" },
        { parameter: "Odor", value: "Faint, characteristic" },
        { parameter: "Taste", value: "Bland, mucilaginous" },
        { parameter: "Particle Size", value: "Maximum 5.0% on U.S.S. 35#" },
        { parameter: "Moisture", value: "Maximum 12.0%" },
        { parameter: "Total Ash", value: "Maximum 4.0%" },
        { parameter: "Acid Insoluble Ash", value: "Maximum 1.0%" },
        { parameter: "Foreign Organic Matter", value: "Maximum 0.5%" },
      ],
      uses: [
        "Maintaining / reducing blood cholesterol levels",
        "Constipation relief",
        "Piles and fissures treatment",
        "Acidity and ulcers management",
        "Supplement for slimming diet programs",
        "Diarrhea, Dysentery and other bowel disorders",
      ],
      packaging: "200 gm / 500 gm / 15 kg / 20 kg / 50 kg",
      shelfLife: "24 months after manufacturing",
      storage: "In covered finished good shed, in dry atmosphere",
    },
    { 
      name: "Fennel Seeds", 
      image: fennelSeedsImg, 
      link: "/seo/fennel-seeds-export",
      description: "Aromatic fennel seeds with high essential oil content",
      botanicalName: "Foeniculum Vulgare",
      familyName: "Apiaceae (Umbelliferae)",
      varieties: "Machine Clean & Sortex",
      availability: "Whole / Grounded (Powder)",
      specifications: [
        { parameter: "Purity", value: "99.85% / 99% / 98%" },
        { parameter: "Extraneous Foreign Matter", value: "0.50% Max" },
        { parameter: "Excreta other", value: "5 mg/lb Max" },
        { parameter: "Mold", value: "1% Max" },
        { parameter: "Total Ash", value: "10% Max" },
        { parameter: "Salmonella", value: "Absent / 25 Gms" },
        { parameter: "Acid Insoluble Ash", value: "1.25% Max" },
      ],
      uses: [
        "Used as mouth fresheners and digestion catalysts",
        "Helps regulate blood pressure",
        "Reduces Constipation, Indigestion, IBS & Bloating",
        "Helps reduce Asthma Symptoms",
        "Helps purify blood by removing toxins",
        "Powerful free radical scavenging properties",
      ],
      packaging: "200 gm / 500 gm / 15 kg / 20 kg / 50 kg",
      shelfLife: "24 months after manufacturing",
      storage: "In covered finished good shed, in dry atmosphere",
    },
    { 
      name: "Cumin Seeds (Jeera)", 
      image: cuminSeedsImg, 
      link: "/more/cumin-export",
      description: "Premium cumin seeds with rich aroma and flavor",
      botanicalName: "Cuminum Cyminum L",
      familyName: "Apiaceae (Umbelliferae)",
      varieties: "Machine Clean & Sortex",
      availability: "Whole / Grounded (Powder)",
      specifications: [
        { parameter: "Purity", value: "99.85% / 99% / 98%" },
        { parameter: "Extraneous Foreign Matter", value: "0.50% Max" },
        { parameter: "Moisture", value: "10% Max" },
        { parameter: "Salmonella", value: "Absent / 25 Gms" },
        { parameter: "Total Ash", value: "9.5% Max" },
        { parameter: "Acid Insoluble Ash", value: "1.75% Max" },
      ],
      uses: [
        "Rich in anti-inflammatory antioxidants",
        "Cumin water helps cure acidity and bloating",
        "Excellent source of iron and dietary fiber",
        "Helps reduce sugar levels for diabetes management",
        "Natural energy booster",
      ],
      packaging: "200 gm / 500 gm / 15 kg / 20 kg / 50 kg",
      shelfLife: "24 months after manufacturing",
      storage: "In covered finished good shed, in dry atmosphere",
    },
    { 
      name: "Cotton", 
      image: cottonImg, 
      link: "/seo/cotton-export-services",
      description: "High-grade cotton for textile manufacturing",
      botanicalName: "Gossypium",
      familyName: "Malvaceae",
      varieties: "Shankar-6, MCU-5, DCH-32",
      availability: "Raw Cotton / Cotton Bales",
      specifications: [
        { parameter: "Staple Length", value: "28-32 mm" },
        { parameter: "Micronaire", value: "3.5-4.9" },
        { parameter: "Strength", value: "26-32 g/tex" },
        { parameter: "Uniformity Index", value: "80-85%" },
        { parameter: "Moisture", value: "8.5% Max" },
        { parameter: "Trash Content", value: "3-5%" },
      ],
      uses: [
        "Textile manufacturing",
        "Medical supplies and bandages",
        "Industrial applications",
        "Home furnishings",
        "Apparel manufacturing",
      ],
      packaging: "170 kg Bales / Bulk Orders",
      shelfLife: "Stable when stored properly",
      storage: "In dry, well-ventilated warehouses",
    },
    { 
      name: "Rice", 
      image: riceImg, 
      link: "/more/rice-export",
      description: "Premium basmati and non-basmati rice varieties",
      botanicalName: "Oryza Sativa",
      familyName: "Poaceae",
      varieties: "Basmati / Non-Basmati / Sella",
      availability: "Raw / Steamed / Parboiled",
      specifications: [
        { parameter: "Grain Length", value: "7.0-8.4 mm (Basmati)" },
        { parameter: "Moisture", value: "12.5% Max" },
        { parameter: "Broken", value: "1-5% Max" },
        { parameter: "Foreign Matter", value: "0.5% Max" },
        { parameter: "Chalky Grains", value: "3% Max" },
        { parameter: "Damage/Discolored", value: "1% Max" },
      ],
      uses: [
        "Culinary preparations worldwide",
        "Biryani and Pulao dishes",
        "Rice flour production",
        "Breakfast cereals",
        "Brewing industry",
      ],
      packaging: "5 kg / 10 kg / 25 kg / 50 kg bags",
      shelfLife: "24 months after manufacturing",
      storage: "Cool, dry place away from direct sunlight",
    },
    { 
      name: "Groundnut (Peanut)", 
      image: groundnutImg, 
      link: "/seo/groundnut-export",
      description: "Quality groundnuts for oil and food processing",
      botanicalName: "Arachis Hypogaea",
      familyName: "Fabaceae",
      varieties: "Bold / Java / Runner",
      availability: "In-Shell / Blanched / Splits",
      specifications: [
        { parameter: "Count per Ounce", value: "38/42, 40/50, 50/60" },
        { parameter: "Moisture", value: "7% Max" },
        { parameter: "Admixture", value: "1% Max" },
        { parameter: "Oil Content", value: "42-48%" },
        { parameter: "Aflatoxin", value: "< 4 ppb" },
        { parameter: "Foreign Matter", value: "0.5% Max" },
      ],
      uses: [
        "Edible oil extraction",
        "Peanut butter production",
        "Confectionery industry",
        "Snack food manufacturing",
        "Animal feed",
      ],
      packaging: "25 kg / 50 kg jute bags / Vacuum packs",
      shelfLife: "12 months after manufacturing",
      storage: "Cool, dry place with proper ventilation",
    },
    { 
      name: "Cardamom", 
      image: cardamomImg, 
      link: "/more/cardamom-export",
      description: "Green and black cardamom with intense aroma",
      botanicalName: "Elettaria Cardamomum",
      familyName: "Zingiberaceae",
      varieties: "Green / Black / Ground",
      availability: "Whole Pods / Seeds / Powder",
      specifications: [
        { parameter: "Size", value: "7mm+ / 6-7mm / 5-6mm" },
        { parameter: "Moisture", value: "10% Max" },
        { parameter: "Volatile Oil", value: "4% Min" },
        { parameter: "Total Ash", value: "8% Max" },
        { parameter: "Light Seeds", value: "5% Max" },
        { parameter: "Extraneous Matter", value: "2% Max" },
      ],
      uses: [
        "Culinary flavoring agent",
        "Traditional medicine and Ayurveda",
        "Perfumery and aromatherapy",
        "Beverage flavoring (tea, coffee)",
        "Confectionery and baking",
      ],
      packaging: "200 gm / 500 gm / 5 kg / 25 kg",
      shelfLife: "24 months after manufacturing",
      storage: "Airtight containers in cool, dark place",
    },
    { 
      name: "Soybean", 
      image: soybeanImg, 
      link: "/seo/soybean-export",
      description: "Non-GMO soybeans for various applications",
      botanicalName: "Glycine Max",
      familyName: "Fabaceae",
      varieties: "Yellow / Black / Green",
      availability: "Whole / Splits / Meal",
      specifications: [
        { parameter: "Protein Content", value: "38-42%" },
        { parameter: "Oil Content", value: "18-20%" },
        { parameter: "Moisture", value: "12% Max" },
        { parameter: "Foreign Matter", value: "2% Max" },
        { parameter: "Damaged Grains", value: "3% Max" },
        { parameter: "GMO Status", value: "Non-GMO" },
      ],
      uses: [
        "Soybean oil extraction",
        "Soy milk and tofu production",
        "Animal feed manufacturing",
        "Soy protein isolate production",
        "Biodiesel production",
      ],
      packaging: "25 kg / 50 kg PP bags / Bulk",
      shelfLife: "12 months after manufacturing",
      storage: "Cool, dry warehouse conditions",
    },
    { 
      name: "Wheat Flour (Atta)", 
      image: wheatFlourImg, 
      link: "/seo/wheat-flour-export-services",
      description: "Fine quality wheat flour for bakery and food industry",
      botanicalName: "Triticum Aestivum",
      familyName: "Poaceae",
      varieties: "Whole Wheat / Maida / Semolina",
      availability: "Fine / Medium / Coarse",
      specifications: [
        { parameter: "Protein Content", value: "10-12%" },
        { parameter: "Moisture", value: "14% Max" },
        { parameter: "Ash Content", value: "0.5-1.5%" },
        { parameter: "Gluten", value: "8-10%" },
        { parameter: "Granulation", value: "98% through 212 microns" },
        { parameter: "Acid Insoluble Ash", value: "0.15% Max" },
      ],
      uses: [
        "Bread and bakery products",
        "Chapati and roti preparation",
        "Pasta and noodle manufacturing",
        "Biscuit and cookie production",
        "Confectionery industry",
      ],
      packaging: "1 kg / 5 kg / 10 kg / 25 kg / 50 kg",
      shelfLife: "6 months after manufacturing",
      storage: "Cool, dry place away from moisture",
    },
  ];

  const certifications = [
    { name: "ISO 9001:2015", icon: Award, color: "text-blue-500" },
    { name: "HACCP", icon: CheckCircle, color: "text-green-500" },
    { name: "FSSAI", icon: Shield, color: "text-purple-500" },
    { name: "Export House", icon: Globe, color: "text-orange-500" },
  ];

  const stats = [
    { label: "Countries Served", value: "50+", icon: Globe },
    { label: "Happy Clients", value: "500+", icon: Users },
    { label: "Products Exported", value: "1000+", icon: Target },
    { label: "Years Experience", value: "15+", icon: Star },
  ];

  const generateStructuredData = () => ({
    "@context": "https://schema.org",
    "@type": "ItemList",
    "name": "Patel Exports Products",
    "description": "Premium agricultural products exported from India",
    "numberOfItems": products.length,
    "itemListElement": products.map((product, index) => ({
      "@type": "ListItem",
      "position": index + 1,
      "item": {
        "@type": "Product",
        "name": product.name,
        "description": product.description,
        "image": product.image,
        "url": `https://patelimpex.com${product.link}`
      }
    }))
  });

  return (
    <>
      <Helmet>
        <title>Our Products | Premium Agricultural Exports | Patel Impex</title>
        <meta name="description" content="Explore our premium agricultural products including Psyllium Husk, Fennel, Cumin, Cotton, Rice, Groundnut, Cardamom, Soybean, and Wheat Flour for global export." />
        <meta name="keywords" content="psyllium husk export, fennel seeds, cumin export, cotton export, rice export, groundnut, cardamom, soybean, wheat flour, agricultural exports India" />
        <link rel="canonical" href="https://patelimpex.com/products" />
        <script type="application/ld+json">
          {JSON.stringify(generateStructuredData())}
        </script>
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navigation />
        
        {/* Hero Section */}
        <section className="pt-32 pb-16 bg-gradient-to-br from-primary/10 via-background to-secondary/10">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-4xl mx-auto">
              <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full mb-6">
                <Wheat className="h-5 w-5" />
                <span className="font-medium">Premium Quality Exports</span>
              </div>
              <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Our Premium Products
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                Quality agricultural products from India, exported worldwide with international certifications and complete documentation.
              </p>
              
              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
                {stats.map((stat, index) => (
                  <div key={index} className="bg-card p-6 rounded-xl shadow-lg">
                    <stat.icon className="h-8 w-8 text-primary mx-auto mb-3" />
                    <div className="text-3xl font-bold text-foreground">{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Products Grid with Details */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Agricultural Products</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                We specialize in exporting premium quality agricultural products to markets worldwide
              </p>
            </div>

            <div className="space-y-16">
              {products.map((product, index) => (
                <Card key={index} className="overflow-hidden border-0 shadow-xl" id={product.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}>
                  <div className="grid lg:grid-cols-3 gap-0">
                    {/* Product Image */}
                    <div className="relative bg-gradient-to-br from-muted/50 to-muted p-8 flex items-center justify-center">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="max-h-72 w-auto object-contain"
                      />
                    </div>
                    
                    {/* Product Details */}
                    <div className="lg:col-span-2 p-8">
                      <div className="flex items-start justify-between mb-6">
                        <div>
                          <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-2">{product.name}</h3>
                          <p className="text-muted-foreground">{product.description}</p>
                        </div>
                        <Link to={product.link}>
                          <Button variant="outline" size="sm" className="gap-2">
                            View Details <ArrowRight className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>

                      {/* Basic Info Table */}
                      <div className="mb-6">
                        <Table>
                          <TableBody>
                            <TableRow>
                              <TableCell className="font-medium">Botanical Name</TableCell>
                              <TableCell className="italic">{product.botanicalName}</TableCell>
                              <TableCell className="font-medium">Family Name</TableCell>
                              <TableCell>{product.familyName}</TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell className="font-medium">Varieties</TableCell>
                              <TableCell>{product.varieties}</TableCell>
                              <TableCell className="font-medium">Availability</TableCell>
                              <TableCell>{product.availability}</TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>

                      {/* Tabs for Specifications, Uses, Packaging */}
                      <Tabs defaultValue="specifications" className="w-full">
                        <TabsList className="grid w-full grid-cols-3">
                          <TabsTrigger value="specifications">Specifications</TabsTrigger>
                          <TabsTrigger value="uses">Uses</TabsTrigger>
                          <TabsTrigger value="packaging">Packing & Storage</TabsTrigger>
                        </TabsList>
                        
                        <TabsContent value="specifications" className="mt-4">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Parameter</TableHead>
                                <TableHead>Value</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {product.specifications.map((spec, specIndex) => (
                                <TableRow key={specIndex}>
                                  <TableCell className="font-medium">{spec.parameter}</TableCell>
                                  <TableCell>{spec.value}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </TabsContent>
                        
                        <TabsContent value="uses" className="mt-4">
                          <ul className="grid md:grid-cols-2 gap-2">
                            {product.uses.map((use, useIndex) => (
                              <li key={useIndex} className="flex items-start gap-2 text-muted-foreground">
                                <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                                <span>{use}</span>
                              </li>
                            ))}
                          </ul>
                        </TabsContent>
                        
                        <TabsContent value="packaging" className="mt-4">
                          <Table>
                            <TableBody>
                              <TableRow>
                                <TableCell className="font-medium">Packaging</TableCell>
                                <TableCell>{product.packaging}</TableCell>
                              </TableRow>
                              <TableRow>
                                <TableCell className="font-medium">Shelf Life</TableCell>
                                <TableCell>{product.shelfLife}</TableCell>
                              </TableRow>
                              <TableRow>
                                <TableCell className="font-medium">Storage</TableCell>
                                <TableCell>{product.storage}</TableCell>
                              </TableRow>
                            </TableBody>
                          </Table>
                          <p className="text-sm text-muted-foreground mt-4">
                            Bulk orders are also available as per client's requirement.
                          </p>
                        </TabsContent>
                      </Tabs>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Certifications */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Our Certifications</h2>
              <p className="text-muted-foreground">Quality assured with international standards</p>
            </div>
            <div className="flex flex-wrap justify-center gap-8">
              {certifications.map((cert, index) => (
                <div key={index} className="flex items-center gap-3 bg-card px-6 py-4 rounded-xl shadow-md">
                  <cert.icon className={`h-8 w-8 ${cert.color}`} />
                  <span className="font-semibold">{cert.name}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-primary to-secondary">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Ready to Start Exporting?
            </h2>
            <p className="text-white/80 mb-8 max-w-2xl mx-auto">
              Contact us today to discuss your requirements and get a competitive quote for bulk orders.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/contact">
                <Button size="lg" variant="secondary" className="gap-2">
                  <Phone className="h-5 w-5" />
                  Contact Us
                </Button>
              </Link>
              <Link to="/inquiry">
                <Button size="lg" variant="outline" className="bg-white/10 text-white border-white/30 hover:bg-white/20 gap-2">
                  <Mail className="h-5 w-5" />
                  Send Inquiry
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

// Shield icon component for certifications
const Shield = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
  </svg>
);

export default Products;
